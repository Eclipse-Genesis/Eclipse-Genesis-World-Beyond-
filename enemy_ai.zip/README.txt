
# Section 5: Enemy AI & Combat System

This section includes a basic enemy that tracks the player and damages them on contact. The player can defeat the enemy by pressing Space when close.

## Features:
- Enemy tracks player position using vector math
- Combat interaction: Spacebar to attack
- Basic health tracking
- Alerts for enemy defeat or player death

## How to Use:
1. Open `index.html` in Replit.
2. Watch the enemy approach.
3. Press Space when close to defeat the enemy.

This is a simple AI and combat demo for building action games.
