
# Section 3: UI + HUD Elements

This section introduces a simple in-game UI overlay showing health, XP, and level.

## Features:
- HUD styled with CSS
- Health bar that decreases
- XP and level display that updates
- Auto-demo logic simulates player activity

## How to Use:
1. Open `index.html` in Replit.
2. Observe the HUD at the top-left updating every 2 seconds.
3. Use this structure to connect to real gameplay mechanics later.

This creates a clean, responsive game overlay in any 3D environment.
