
# Section 7: Quest & Dialogue System

This section shows a basic quest and dialogue interaction system.

## Features:
- Dialogue messages appear as speech boxes
- Quests are added, tracked, and completed with state updates
- A quest log is displayed in the corner

## How to Use:
1. Open `index.html` in Replit.
2. After a moment, dialogue will start and a quest appears.
3. After more time, quest will auto-complete (demo purposes).

This is a good foundation for RPG-style quests and NPC interactions.
