
# Section 13: NPC Dialog System with Branching Choices

This section implements an interactive NPC dialog system using a dialog tree.

## Features:
- Branching dialog based on player choice
- Dynamic updating of conversation
- Modular dialog tree structure

## Usage:
1. Open `index.html` in Replit.
2. Read the dialog and click choices to proceed through the conversation.

### Expand with:
- Dialog conditions (e.g. based on quests or inventory)
- Voiceover or text effects
- Firebase save/load of dialog state
