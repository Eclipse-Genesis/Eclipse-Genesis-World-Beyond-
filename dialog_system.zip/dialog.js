
const dialogTree = {
  start: {
    text: "Hello traveler! What brings you here?",
    choices: [
      { text: "I'm looking for adventure.", next: "adventure" },
      { text: "Just passing by.", next: "passing" }
    ]
  },
  adventure: {
    text: "Ah, a brave soul! There's a cave nearby full of danger and treasure.",
    choices: [
      { text: "Tell me more.", next: "details" },
      { text: "Maybe later.", next: "end" }
    ]
  },
  passing: {
    text: "Safe travels, then.",
    choices: []
  },
  details: {
    text: "The cave lies beyond the forest. Beware of the creatures within.",
    choices: [
      { text: "Thanks for the warning.", next: "end" }
    ]
  },
  end: {
    text: "Farewell, traveler.",
    choices: []
  }
};

function displayNode(nodeKey) {
  const node = dialogTree[nodeKey];
  document.getElementById("dialogText").innerText = node.text;
  const choicesContainer = document.getElementById("choices");
  choicesContainer.innerHTML = "";

  node.choices.forEach(choice => {
    const choiceEl = document.createElement("div");
    choiceEl.className = "choice";
    choiceEl.innerText = choice.text;
    choiceEl.onclick = () => displayNode(choice.next);
    choicesContainer.appendChild(choiceEl);
  });
}

displayNode("start");
