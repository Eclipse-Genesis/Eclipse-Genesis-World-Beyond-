
# Trading System
Shows market items with prices. Can be enhanced to support player-to-player trades and Firebase backend.
