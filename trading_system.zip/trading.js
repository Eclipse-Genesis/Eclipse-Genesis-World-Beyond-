
const marketItems = [{ name: "Iron Ore", price: 10 }, { name: "Magic Scroll", price: 50 }];
const tradeDiv = document.getElementById("trade");
function renderMarket() {
  tradeDiv.innerHTML = marketItems.map(item => `<div>${item.name}: ${item.price} gold</div>`).join('');
}
renderMarket();
