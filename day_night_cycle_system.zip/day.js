
const timeDisplay = document.getElementById("timeDisplay");
let hour = 6;
function updateTime() {
  hour = (hour + 1) % 24;
  timeDisplay.textContent = hour < 12 ? "Morning" : hour < 18 ? "Afternoon" : "Night";
}
setInterval(updateTime, 3000);
updateTime();
