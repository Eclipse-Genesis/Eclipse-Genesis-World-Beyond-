
// CONFIGURE YOUR FIREBASE BELOW
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

function saveData() {
  const user = document.getElementById("username").value;
  const data = document.getElementById("gamedata").value;

  db.ref("users/" + user).set({
    savedData: data
  }).then(() => {
    document.getElementById("output").innerText = "Saved successfully!";
  }).catch(err => {
    document.getElementById("output").innerText = "Save failed: " + err;
  });
}

function loadData() {
  const user = document.getElementById("username").value;

  db.ref("users/" + user).get().then((snapshot) => {
    if (snapshot.exists()) {
      document.getElementById("output").innerText = "Loaded: " + JSON.stringify(snapshot.val());
    } else {
      document.getElementById("output").innerText = "No data found.";
    }
  }).catch(err => {
    document.getElementById("output").innerText = "Load failed: " + err;
  });
}
