
# Section 14: Save/Load System with Firebase

This example allows saving and loading of game data to Firebase Realtime Database.

## Features:
- Save any text data by username
- Load data by the same username
- Uses Firebase JS SDK v9 (compat)

## Setup:
1. Replace the config object in `firebase_save_load.js` with your Firebase project settings.
2. Enable Realtime Database in Firebase console.
3. Host on Replit or Firebase Hosting if needed.

### Notes:
- You can integrate this with inventory, quests, and player stats.
- Always sanitize inputs for production.
