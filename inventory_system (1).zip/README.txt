
# Section 26: In-Game Inventory and Item System

This module demonstrates a grid-based item inventory system using HTML, CSS, and JavaScript.

## Features:
- Dynamic grid inventory with 20 slots
- Random item generator
- Real-time rendering of added items
- Slot-based layout

## Setup:
1. Open `index.html` in Replit or your browser.
2. Click "Add Random Item" to simulate collecting in-game items.
3. Inventory will visually update with items in a grid format.

## Expansion Ideas:
- Add item tooltips and icons
- Drag-and-drop to reorder items
- Integrate item storage in Firebase
- Enable equipping and using items
