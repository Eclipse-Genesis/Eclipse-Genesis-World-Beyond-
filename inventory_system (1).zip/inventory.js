
const inventory = [];
const maxSlots = 20;

function getRandomItem() {
  const items = ["Sword", "Shield", "Potion", "Helmet", "Boots", "Ring"];
  return items[Math.floor(Math.random() * items.length)];
}

function addItem() {
  if (inventory.length >= maxSlots) {
    alert("Inventory full!");
    return;
  }

  const item = getRandomItem();
  inventory.push(item);
  renderInventory();
}

function renderInventory() {
  const grid = document.getElementById("inventoryGrid");
  grid.innerHTML = "";
  for (let i = 0; i < maxSlots; i++) {
    const slot = document.createElement("div");
    slot.className = "slot";
    if (inventory[i]) {
      const itemDiv = document.createElement("div");
      itemDiv.className = "item";
      itemDiv.innerText = inventory[i];
      slot.appendChild(itemDiv);
    }
    grid.appendChild(slot);
  }
}

renderInventory();
