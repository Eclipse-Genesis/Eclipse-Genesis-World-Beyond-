
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getDatabase, ref, set, onValue } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-database.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Generate random player ID
const playerId = "player_" + Math.floor(Math.random() * 10000);
const playerRef = ref(db, "players/" + playerId);

// Set initial position
const position = { x: 0, y: 0 };
set(playerRef, position);

// Update position every second
setInterval(() => {
  position.x += Math.random() * 2 - 1;
  position.y += Math.random() * 2 - 1;
  set(playerRef, position);
}, 1000);

// Listen to all players
const allPlayersRef = ref(db, "players/");
onValue(allPlayersRef, (snapshot) => {
  console.clear();
  console.log("All Players:");
  snapshot.forEach((child) => {
    console.log(child.key, child.val());
  });
});
