
const players = [];

function joinLobby() {
  const nameInput = document.getElementById("playerName");
  const name = nameInput.value.trim();
  if (name && !players.includes(name)) {
    players.push(name);
    nameInput.value = "";
    updateLobby();
  }
}

function updateLobby() {
  const list = document.getElementById("playersList");
  list.innerHTML = "";
  players.forEach(player => {
    const div = document.createElement("div");
    div.className = "player";
    div.innerText = player;
    list.appendChild(div);
  });
}
