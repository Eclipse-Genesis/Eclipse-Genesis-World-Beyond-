
const music = document.getElementById('bgMusic');
const sfx = document.getElementById('sfx');

function playMusic() {
  music.play();
}

function pauseMusic() {
  music.pause();
}

function playSFX() {
  sfx.currentTime = 0;
  sfx.play();
}
