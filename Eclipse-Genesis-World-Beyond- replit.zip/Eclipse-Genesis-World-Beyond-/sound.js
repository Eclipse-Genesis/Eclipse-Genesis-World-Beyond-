
let musicPlaying = false;

function playSFX() {
  const sfx = document.getElementById("sfx");
  sfx.currentTime = 0;
  sfx.play();
}

function toggleMusic() {
  const bgm = document.getElementById("bgm");
  if (musicPlaying) {
    bgm.pause();
  } else {
    bgm.play();
  }
  musicPlaying = !musicPlaying;
}
