
// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, doc, setDoc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// Firebase config (you must replace this with your own Firebase project's config)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-app.firebaseapp.com",
  projectId: "your-app",
  storageBucket: "your-app.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdefg12345"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function saveGame() {
  const username = document.getElementById("username").value;
  const xp = parseInt(document.getElementById("xp").value);
  if (!username) return alert("Username is required.");
  await setDoc(doc(db, "saves", username), { xp });
  document.getElementById("output").textContent = "Game saved for " + username;
}

async function loadGame() {
  const username = document.getElementById("username").value;
  if (!username) return alert("Username is required.");
  const docRef = doc(db, "saves", username);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    const data = docSnap.data();
    document.getElementById("xp").value = data.xp;
    document.getElementById("output").textContent = "Loaded XP: " + data.xp;
  } else {
    document.getElementById("output").textContent = "No data found.";
  }
}
