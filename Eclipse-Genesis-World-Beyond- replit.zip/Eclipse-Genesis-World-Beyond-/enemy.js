
import * as THREE from 'three';

let scene, camera, renderer;
let player, enemy;
let enemySpeed = 0.02;
let health = 100;

init();
animate();

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111111);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 5, 10);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(0, 20, 10);
  scene.add(light);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(100, 100),
    new THREE.MeshPhongMaterial({ color: 0x003300 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const playerGeom = new THREE.BoxGeometry(1, 2, 1);
  const playerMat = new THREE.MeshStandardMaterial({ color: 0x00aaff });
  player = new THREE.Mesh(playerGeom, playerMat);
  player.position.y = 1;
  scene.add(player);

  const enemyGeom = new THREE.BoxGeometry(1.5, 2.5, 1.5);
  const enemyMat = new THREE.MeshStandardMaterial({ color: 0xff0000 });
  enemy = new THREE.Mesh(enemyGeom, enemyMat);
  enemy.position.set(5, 1.25, 0);
  scene.add(enemy);

  document.addEventListener('keydown', handleInput);
}

function handleInput(event) {
  if (event.key === ' ') {
    attackEnemy();
  }
}

function attackEnemy() {
  const distance = player.position.distanceTo(enemy.position);
  if (distance < 2) {
    scene.remove(enemy);
    alert("Enemy defeated!");
  }
}

function animate() {
  requestAnimationFrame(animate);

  const direction = new THREE.Vector3();
  direction.subVectors(player.position, enemy.position).normalize();
  enemy.position.add(direction.multiplyScalar(enemySpeed));

  if (player.position.distanceTo(enemy.position) < 1.2) {
    if (health > 0) {
      health -= 1;
      console.log("Player Health:", health);
      if (health <= 0) {
        alert("You were defeated!");
      }
    }
  }

  camera.lookAt(player.position);
  renderer.render(scene, camera);
}
