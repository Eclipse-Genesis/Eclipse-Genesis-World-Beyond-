
function startGame() {
  alert("Starting game... (load game scene)");
  // Simulate scene transition
  window.location.href = "game.html"; // example redirection
}

function openOptions() {
  alert("Options screen coming soon!");
}

function exitGame() {
  alert("Exiting game...");
}
