
import * as THREE from 'three';

let scene, camera, renderer;
let player;
let playerHealth = 100;
let xp = 0;
let level = 1;

init();
animate();

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x333333);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.z = 5;

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
  player = new THREE.Mesh(geometry, material);
  scene.add(player);

  updateHUD();
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

function updateHUD() {
  document.getElementById("xp").innerText = xp;
  document.getElementById("level").innerText = level;
  document.getElementById("healthBar").style.width = playerHealth + "%";
}

function takeDamage(amount) {
  playerHealth = Math.max(0, playerHealth - amount);
  updateHUD();
}

function gainXP(amount) {
  xp += amount;
  if (xp >= 100) {
    xp = 0;
    level++;
  }
  updateHUD();
}

// Simulate taking damage and gaining XP for demo
setInterval(() => {
  takeDamage(5);
  gainXP(10);
}, 2000);
