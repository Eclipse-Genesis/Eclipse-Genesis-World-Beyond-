
const quests = [
  { title: "Collect 10 Herbs", description: "Find and gather herbs in the forest.", completed: false },
  { title: "Defeat 5 Enemies", description: "Battle and defeat five enemies.", completed: false },
  { title: "Find the Lost Key", description: "Search the ruins for a mysterious key.", completed: false },
  { title: "Speak to the Village Elder", description: "Talk to the elder in the mountain village.", completed: false }
];

function renderQuests() {
  const container = document.getElementById("quests");
  container.innerHTML = "";
  quests.forEach((quest, index) => {
    const questEl = document.createElement("div");
    questEl.className = "quest" + (quest.completed ? " completed" : "");
    questEl.innerHTML = `<strong>${quest.title}</strong><p>${quest.description}</p><p>Status: ${quest.completed ? "Completed" : "Incomplete"}</p>`;
    container.appendChild(questEl);
  });
}

function completeRandomQuest() {
  const incomplete = quests.filter(q => !q.completed);
  if (incomplete.length === 0) {
    alert("All quests completed!");
    return;
  }
  const quest = incomplete[Math.floor(Math.random() * incomplete.length)];
  quest.completed = true;
  alert(`Quest Completed: ${quest.title}`);
  renderQuests();
}

renderQuests();
