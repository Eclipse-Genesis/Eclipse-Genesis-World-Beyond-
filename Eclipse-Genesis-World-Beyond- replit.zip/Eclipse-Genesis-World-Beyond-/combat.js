
let playerHealth = 100;
let enemyHealth = 100;

function updateBars() {
  document.getElementById("playerHealth").style.width = playerHealth + "%";
  document.getElementById("enemyHealth").style.width = enemyHealth + "%";
}

function attackEnemy() {
  const damage = Math.floor(Math.random() * 20) + 5;
  enemyHealth = Math.max(0, enemyHealth - damage);
  logAction("Player attacks Enemy for " + damage + " damage.");
  updateBars();
  checkGameOver();
}

function attackPlayer() {
  const damage = Math.floor(Math.random() * 15) + 5;
  playerHealth = Math.max(0, playerHealth - damage);
  logAction("Enemy attacks Player for " + damage + " damage.");
  updateBars();
  checkGameOver();
}

function logAction(msg) {
  const log = document.getElementById("log");
  log.textContent = msg;
}

function checkGameOver() {
  if (playerHealth <= 0) {
    logAction("Player is defeated!");
  }
  if (enemyHealth <= 0) {
    logAction("Enemy is defeated!");
  }
}

updateBars();
