
# Section 30: Audio System – Background Music and SFX

This module adds basic audio capabilities to the game.

## Features:
- Background music with play/pause controls
- Sound effects (SFX) on button press
- HTML5 `<audio>` usage for browser compatibility

## Setup:
1. Add your own `bg_music.mp3` and `sfx.mp3` files into the directory.
2. Open `index.html` to test playback.
3. Adjust volume, loop behavior, or add dynamic sound triggers via JS.

## Expansion Ideas:
- Add volume controls or mute toggles
- Trigger SFX on gameplay events
- Use Firebase Storage to load audio from the cloud
