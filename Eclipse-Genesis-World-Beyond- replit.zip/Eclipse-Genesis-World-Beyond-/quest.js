
let dialogueBox = document.getElementById("dialogueBox");
let questLog = document.getElementById("quests");

let currentQuest = null;
let quests = [];

function startDialogue(text, callback) {
  dialogueBox.textContent = text;
  setTimeout(callback, 3000);
}

function addQuest(name, description) {
  quests.push({ name, description, completed: false });
  updateQuestLog();
}

function completeQuest(name) {
  const quest = quests.find(q => q.name === name);
  if (quest) {
    quest.completed = true;
    updateQuestLog();
    startDialogue("Quest Complete: " + name, () => {});
  }
}

function updateQuestLog() {
  questLog.innerHTML = '';
  quests.forEach(q => {
    const item = document.createElement("li");
    item.textContent = q.name + (q.completed ? " (Done)" : "");
    questLog.appendChild(item);
  });
}

// Simulated interaction
setTimeout(() => {
  startDialogue("Hello traveler! Could you bring me 3 berries?", () => {
    addQuest("Find Berries", "Collect 3 berries from the forest.");
  });
}, 2000);

setTimeout(() => {
  startDialogue("You found the berries? Thank you!", () => {
    completeQuest("Find Berries");
  });
}, 10000);
