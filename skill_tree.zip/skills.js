
const skills = [
  { id: 1, name: "Fireball", desc: "Shoot a powerful fireball", unlocked: true },
  { id: 2, name: "Ice Shield", desc: "Block damage with an ice shield", unlocked: false },
  { id: 3, name: "Lightning Dash", desc: "Teleport a short distance", unlocked: false },
  { id: 4, name: "Heal", desc: "Restore health", unlocked: false },
];

function renderSkills() {
  const container = document.getElementById("skillTree");
  container.innerHTML = "";
  skills.forEach(skill => {
    const el = document.createElement("div");
    el.className = "skill " + (skill.unlocked ? "unlocked" : "locked");
    el.innerHTML = `<h3>${skill.name}</h3><p>${skill.desc}</p>`;
    el.onclick = () => unlockSkill(skill.id);
    container.appendChild(el);
  });
}

function unlockSkill(id) {
  const skill = skills.find(s => s.id === id);
  if (!skill.unlocked) {
    skill.unlocked = true;
    renderSkills();
  }
}

renderSkills();
