
# Section 27: Skill Tree and Abilities System

This module provides a visual and interactive skill tree where players can unlock abilities.

## Features:
- Skill boxes with lock/unlock state
- Click to unlock a skill
- Dynamic rendering of ability tree

## Setup:
1. Open `index.html` in Replit or a browser.
2. Click on locked skills to unlock them.

## Expansion Ideas:
- Add dependencies (e.g., unlock Fireball before Lightning Dash)
- Store skill progress in Firebase
- Show player stats affected by skills
- Add animations and sounds
