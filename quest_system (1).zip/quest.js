
const quests = [
  { name: "Find the Crystal", completed: false },
  { name: "Defeat the Goblin Chief", completed: false }
];
const questDiv = document.getElementById("quests");
function displayQuests() {
  questDiv.innerHTML = quests.map(q => `<div>${q.name} - ${q.completed ? "Done" : "Pending"}</div>`).join('');
}
displayQuests();
