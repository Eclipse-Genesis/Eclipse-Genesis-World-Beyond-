
# Quest System
Lists active quests and tracks completion. Expand to integrate with story progression or Firebase.
