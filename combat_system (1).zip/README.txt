
# Combat System
Simulates random attacks and logs damage output. Future features: enemy AI, animations, and multiplayer sync.
