
const log = document.getElementById("combatLog");
function attack() {
  const damage = Math.floor(Math.random() * 20);
  log.innerHTML += `<div>You hit the enemy for ${damage} damage.</div>`;
}
setInterval(attack, 2000);
