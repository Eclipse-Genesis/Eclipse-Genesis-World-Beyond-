
# Section 17: 3D Character Animation System

This example loads a 3D character model and plays its animation using Three.js and GLTFLoader.

## Features:
- Load `.glb` format 3D model
- Play idle/walk/run animations
- Responsive camera and lighting

## How to Use:
1. Add your `character.glb` model to this folder.
2. Open `index.html` in Replit preview or local server.
3. Watch your 3D character animate in the scene!

### Notes:
- Use Blender or Mixamo to generate `.glb` animated models.
- Use Three.js animation mixer for controlling animation states.
