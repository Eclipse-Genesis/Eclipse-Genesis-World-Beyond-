
# Character Customization System
Lets users create characters by selecting name and class. Expand with appearance customization and Firebase save.
