
document.getElementById("characterForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const charClass = document.getElementById("class").value;
  document.getElementById("summary").innerHTML = `Character Created: ${name} the ${charClass}`;
});
