
# Section 21: Real-Time Chat and Notifications (Firebase)

This is a basic real-time chat system using Firebase Realtime Database.

## Features:
- Instant messaging using Firebase
- Scrollable message log
- Auto-scroll to latest messages
- Keyboard "Enter" support

## Setup:
1. Replace the Firebase config in `chat.js` with your own project credentials.
2. Run `index.html` in Replit or locally.
3. Open in multiple tabs or devices to test real-time chat.

## Next Steps:
- Add user IDs or authentication
- Include timestamps and usernames
- Add push notifications (Firebase Cloud Messaging)
