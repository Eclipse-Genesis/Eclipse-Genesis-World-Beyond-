
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = { x: 100, y: 200, mounted: false };
let vehicle = { x: 300, y: 200, speed: 3 };

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw vehicle (e.g., horse or boat)
  ctx.fillStyle = "#a52a2a";
  ctx.fillRect(vehicle.x, vehicle.y, 80, 40);
  ctx.fillStyle = "#fff";
  ctx.fillText("Vehicle", vehicle.x + 10, vehicle.y + 25);

  // Draw player
  ctx.fillStyle = player.mounted ? "#0f0" : "#00f";
  ctx.beginPath();
  ctx.arc(player.x, player.y, 20, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.fillText("Player", player.x - 20, player.y - 25);
}

function update() {
  if (player.mounted) {
    vehicle.x += vehicle.speed;
    player.x = vehicle.x + 30;
  }
  draw();
}

function toggleMount() {
  const distance = Math.abs(player.x - vehicle.x);
  if (distance < 60) {
    player.mounted = !player.mounted;
  }
}

setInterval(update, 50);
