
# Section 25: Vehicle and Mount System

This is a simple mountable vehicle system using JavaScript canvas.

## Features:
- Mount and dismount from a vehicle
- Vehicle moves and carries player when mounted
- Visual feedback of mounting status

## Setup:
1. Open `index.html` in Replit or your browser.
2. Press the "Mount / Dismount" button to toggle player mount state.
3. When mounted, the player moves with the vehicle.

## Expansion Ideas:
- Add vehicle types (horses, boats, gliders)
- Store mount status in Firebase
- Enable player control while mounted
- Add mount stats and stamina
