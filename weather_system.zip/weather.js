
const weatherStates = ["Sunny", "Rainy", "Stormy", "Cloudy"];
const weatherDisplay = document.getElementById("weatherDisplay");
function changeWeather() {
  const newWeather = weatherStates[Math.floor(Math.random() * weatherStates.length)];
  weatherDisplay.textContent = newWeather;
}
setInterval(changeWeather, 5000);
