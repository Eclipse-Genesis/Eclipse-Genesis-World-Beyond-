
# Map Exploration System
Displays a canvas-based map with zones. Can be expanded with fog-of-war, region names, and player movement tracking.
