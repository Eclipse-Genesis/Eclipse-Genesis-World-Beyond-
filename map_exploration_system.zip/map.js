
const canvas = document.getElementById("mapCanvas");
const ctx = canvas.getContext("2d");
ctx.fillStyle = "green";
ctx.fillRect(50, 50, 100, 100);
ctx.fillStyle = "blue";
ctx.fillRect(200, 100, 150, 150);
