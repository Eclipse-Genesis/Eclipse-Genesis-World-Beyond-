
# Section 2: Movement & Character Controller

This section adds a basic player cube that can move with WASD keys using simple vector logic.

## Features:
- WASD movement
- Character is a red cube
- Ground plane and camera that follows the player

## How to Use:
1. Open index.html in Replit
2. Move the character with W/A/S/D
3. Observe how the camera tracks movement

This is the foundation for more advanced character controllers with animations and physics.
