
import * as THREE from 'three';

let scene, camera, renderer;
let player, keys = {};
let velocity = new THREE.Vector3();
const speed = 5;

init();
animate();

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87ceeb);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.set(0, 5, 10);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(0, 10, 10);
  scene.add(light);
  scene.add(new THREE.AmbientLight(0x404040));

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(100, 100),
    new THREE.MeshLambertMaterial({ color: 0x228B22 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const geometry = new THREE.BoxGeometry(1, 2, 1);
  const material = new THREE.MeshStandardMaterial({ color: 0xff4444 });
  player = new THREE.Mesh(geometry, material);
  player.position.y = 1;
  scene.add(player);

  window.addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
  window.addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);
}

function animate() {
  requestAnimationFrame(animate);
  const delta = 0.016;

  velocity.set(0, 0, 0);
  if (keys['w']) velocity.z -= speed * delta;
  if (keys['s']) velocity.z += speed * delta;
  if (keys['a']) velocity.x -= speed * delta;
  if (keys['d']) velocity.x += speed * delta;

  player.position.add(velocity);

  camera.position.x = player.position.x + 5;
  camera.position.z = player.position.z + 10;
  camera.lookAt(player.position);

  renderer.render(scene, camera);
}
