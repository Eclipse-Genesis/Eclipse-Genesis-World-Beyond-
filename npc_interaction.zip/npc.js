
const npcName = document.getElementById("npcName");
const npcDialogue = document.getElementById("npcDialogue");
const dialogueOptions = document.getElementById("dialogueOptions");

const dialogues = {
  greeter: {
    name: "Elder Lumos",
    lines: [
      {
        text: "Welcome, traveler. What brings you to our village?",
        options: [
          { text: "I'm just exploring.", next: 1 },
          { text: "Looking for quests.", next: 2 }
        ]
      },
      {
        text: "The lands are dangerous, be cautious. Safe travels.",
        options: []
      },
      {
        text: "Ah! You should visit the town board. Plenty of tasks await!",
        options: []
      }
    ]
  }
};

let currentDialogue = dialogues.greeter;
let currentLine = 0;

function displayLine(lineIndex) {
  const line = currentDialogue.lines[lineIndex];
  if (!line) return;
  npcName.textContent = currentDialogue.name;
  npcDialogue.textContent = line.text;
  dialogueOptions.innerHTML = '';
  line.options.forEach(option => {
    const btn = document.createElement("button");
    btn.textContent = option.text;
    btn.onclick = () => displayLine(option.next);
    dialogueOptions.appendChild(btn);
  });
}

displayLine(0);
