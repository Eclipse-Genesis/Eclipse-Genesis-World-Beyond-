
# Section 34: NPC Interaction and Dialogue System

## Description
This system simulates interaction with non-player characters (NPCs) using structured dialogue trees. The player can make choices, and the NPC will respond based on selected options.

## Features:
- NPCs have names and multiple dialogue branches
- Player choices determine the flow of conversation
- Easily expandable dialogue structure

## Setup:
1. Open `index.html` to interact with the default NPC.
2. Modify the `dialogues` object in `npc.js` to add more NPCs, lines, and branching dialogues.

## Future Enhancements:
- Add images or 3D models for NPCs
- Trigger events based on dialogue outcomes
- Persist conversation history using Firebase
- Voice acting or text-to-speech support
