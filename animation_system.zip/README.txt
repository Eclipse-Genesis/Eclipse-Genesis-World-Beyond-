
# Animation System
Basic animation using requestAnimationFrame. Expand to include character movement and sprite animations.
