
const scores = [{ name: "Alice", score: 120 }, { name: "Bob", score: 110 }];
const list = document.getElementById("leaderboard");
list.innerHTML = scores.map(s => `<li>${s.name}: ${s.score}</li>`).join('');
