
# Leaderboard System
Displays top players. Expand by sorting and syncing with Firebase database.
