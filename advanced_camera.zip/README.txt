
# Section 18: Advanced Camera System and Cinematic Controls

This setup demonstrates a camera system with:
- Orbit Controls (mouse drag/zoom)
- Cinematic fly-through using a path of points

## Usage:
1. Open `index.html` in Replit or your browser.
2. Watch the camera automatically move in a cinematic path.
3. You can rotate and zoom the view with your mouse.

## Features to Expand:
- Add keyframes and splines (e.g. CatmullRomCurve3)
- Trigger cutscenes based on gameplay events
- Dynamic camera target tracking for moving objects
