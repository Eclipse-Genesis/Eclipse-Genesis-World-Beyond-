
let scene, camera, renderer, controls, clock;
let cinematicPath, cameraTarget, currentPoint = 0;

init();

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x101010);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 2, 5);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const light = new THREE.PointLight(0xffffff, 1, 100);
  light.position.set(0, 10, 10);
  scene.add(light);

  controls = new THREE.OrbitControls(camera, renderer.domElement);

  // Cinematic Path
  cinematicPath = [
    new THREE.Vector3(0, 2, 5),
    new THREE.Vector3(5, 3, 0),
    new THREE.Vector3(0, 2, -5),
    new THREE.Vector3(-5, 3, 0),
    new THREE.Vector3(0, 2, 5)
  ];
  cameraTarget = new THREE.Vector3(0, 0, 0);

  clock = new THREE.Clock();

  animate();
}

function animate() {
  requestAnimationFrame(animate);

  const delta = clock.getDelta();
  const time = clock.elapsedTime;

  // Move camera along the path
  const pathSpeed = 0.5;
  const segment = (time * pathSpeed) % cinematicPath.length;
  const index = Math.floor(segment);
  const lerpFactor = segment % 1;

  const from = cinematicPath[index];
  const to = cinematicPath[(index + 1) % cinematicPath.length];

  camera.position.lerpVectors(from, to, lerpFactor);
  camera.lookAt(cameraTarget);

  controls.update();
  renderer.render(scene, camera);
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
