
# Achievement System
Displays earned achievements. Expand to unlock hidden ones and store player progress on Firebase.
