
const achievements = ["First Blood", "Explorer", "Master Crafter"];
const achievementsDiv = document.getElementById("achievements");
achievementsDiv.innerHTML = achievements.map(a => `<div>${a}</div>`).join('');
