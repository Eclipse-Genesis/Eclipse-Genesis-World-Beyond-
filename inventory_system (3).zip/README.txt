
# Inventory and Equipment System
Tracks player inventory and displays items. Expand by adding Firebase support or drag-and-drop functionality.
