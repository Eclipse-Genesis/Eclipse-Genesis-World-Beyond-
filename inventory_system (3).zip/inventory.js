
const inventory = ["Sword", "Potion", "Shield"];
const invDiv = document.getElementById("inventory");
function renderInventory() {
  invDiv.innerHTML = inventory.map(item => `<div>${item}</div>`).join('');
}
renderInventory();
