
import * as THREE from 'three';
import SimplexNoise from 'simplex-noise';

let scene, camera, renderer, terrain;
const noise = new SimplexNoise();

init();
animate();

function generateHeight(x, z) {
  return noise.noise2D(x * 0.05, z * 0.05) * 10;
}

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87ceeb); // Sky blue

  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 30, 50);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(50, 100, 50);
  scene.add(light);

  const geometry = new THREE.PlaneGeometry(100, 100, 100, 100);
  geometry.rotateX(-Math.PI / 2);

  const vertices = geometry.attributes.position;
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i);
    const z = vertices.getZ(i);
    const y = generateHeight(x, z);
    vertices.setY(i, y);
  }
  geometry.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({ color: 0x228B22, wireframe: false });
  terrain = new THREE.Mesh(geometry, material);
  scene.add(terrain);
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}
