
# Section 6: Terrain & Environment Generation

This section uses Simplex noise to generate 3D terrain in real time.

## Features:
- 100x100 plane subdivided for smooth hills
- Simplex noise for realistic, natural elevation
- Dynamic lighting and camera angle
- Sky-colored background

## How to Use:
1. Open `index.html` in Replit.
2. A procedurally generated green terrain will appear.
3. Use this terrain base for adding trees, water, NPCs, etc.

Great for open-world, survival, or adventure games!
