
# Section 12: Quest System with Objectives and Rewards

This system manages quest tracking, completion, and basic interactions.

## Features:
- Quest display with titles and descriptions
- Visual completion state
- Random quest completion simulation

## Usage:
1. Open `index.html` in Replit.
2. Click "Complete Random Quest" to simulate quest progress.

### Expand with:
- Firebase save/load support
- Multiple quest types (fetch, defeat, explore)
- Rewards and dialogue interaction
