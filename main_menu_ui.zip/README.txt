
# Section 15: Main Menu and UI Navigation System

This is a polished main menu UI system to launch or configure your game.

## Features:
- Centered, stylized UI
- Button-based interaction for Start, Options, and Exit
- Easy redirection logic

## Usage:
1. Open `index.html` on Replit.
2. Click buttons to simulate menu navigation.
3. Replace `window.location.href` to transition to your real game scene/page.

### Expand with:
- Animated logo or transitions
- Sound effects or music
- Options and settings submenus
