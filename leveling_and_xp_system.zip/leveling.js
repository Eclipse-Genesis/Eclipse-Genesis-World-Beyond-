
let xp = 0, level = 1;
function gainXP() {
  xp += 10;
  if (xp >= level * 50) {
    xp = 0;
    level++;
  }
  document.getElementById("levelDisplay").textContent = "Level: " + level;
  document.getElementById("xpDisplay").textContent = "XP: " + xp;
}
