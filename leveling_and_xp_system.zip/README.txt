
# Leveling and XP System
Tracks XP and levels. Expands with stats increase and abilities unlocks.
