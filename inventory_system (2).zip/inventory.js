
// Firebase config (replace with your actual config)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  databaseURL: "https://your-project.firebaseio.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const inventoryGrid = document.getElementById("inventoryGrid");
const userId = "player1"; // replace or make dynamic

function renderInventory(items) {
  inventoryGrid.innerHTML = '';
  for (let i = 0; i < 20; i++) {
    const item = items[i] || { name: 'Empty' };
    const slot = document.createElement("div");
    slot.className = "slot";
    slot.textContent = item.name;
    inventoryGrid.appendChild(slot);
  }
}

function loadInventory() {
  db.ref("inventory/" + userId).get().then(snapshot => {
    const items = snapshot.exists() ? snapshot.val().items : [];
    renderInventory(items);
  });
}

function saveInventory(items) {
  db.ref("inventory/" + userId).set({ items: items });
}

loadInventory(); // Load on page open
