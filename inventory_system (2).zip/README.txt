
# Section 32: Inventory System with UI and Firebase Integration

## Description
This module is a simple 5x4 inventory system rendered in HTML/CSS and connected to Firebase Realtime Database. It shows a grid of item slots, each representing an item or being empty.

## Features:
- Grid-based item display
- Save/load functionality through Firebase
- Modular system to expand into drag-and-drop, icons, categories, etc.

## Setup:
1. Replace Firebase config in `inventory.js` with your project credentials.
2. Modify `userId` to reflect the current player or session.
3. Run `index.html` to view and interact with the inventory.

## Future Improvements:
- Add item tooltips, quantities, icons
- Integrate with game logic for equipping/using items
- Enable drag-and-drop rearrangement
