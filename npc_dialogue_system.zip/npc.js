
const dialogues = ["Hello, traveler!", "Be careful in the forest...", "The king is looking for brave souls."];
const dialogueDiv = document.getElementById("dialogue");
let current = 0;
function showDialogue() {
  dialogueDiv.textContent = dialogues[current];
  current = (current + 1) % dialogues.length;
}
setInterval(showDialogue, 3000);
showDialogue();
