
# NPC Dialogue System
Cycles through NPC messages. Can expand to include branching dialogues and voice-over support.
