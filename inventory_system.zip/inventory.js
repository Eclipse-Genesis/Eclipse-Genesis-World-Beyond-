
const inventory = [];
const maxSlots = 20;
const itemTypes = ["Sword", "Shield", "Potion", "Key", "Gem"];
const inventoryEl = document.getElementById("inventory");

function renderInventory() {
  inventoryEl.innerHTML = '';
  for (let i = 0; i < maxSlots; i++) {
    const slot = document.createElement("div");
    slot.className = "slot";
    if (inventory[i]) {
      slot.textContent = inventory[i];
    }
    slot.onclick = () => selectSlot(i);
    inventoryEl.appendChild(slot);
  }
}

function addItem() {
  const index = inventory.findIndex(i => i === undefined);
  if (index === -1) {
    alert("Inventory Full!");
    return;
  }
  inventory[index] = itemTypes[Math.floor(Math.random() * itemTypes.length)];
  renderInventory();
}

function selectSlot(i) {
  const slots = document.querySelectorAll(".slot");
  slots.forEach((s, idx) => s.classList.toggle("selected", idx === i));
  if (inventory[i]) {
    alert("Selected: " + inventory[i]);
  }
}

renderInventory();
