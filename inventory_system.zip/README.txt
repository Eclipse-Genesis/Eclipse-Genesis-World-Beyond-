
# Section 10: Inventory System & Item Interaction

This section implements a grid-based inventory system.

## Features:
- 5x4 inventory grid (20 slots)
- Items randomly added from a preset list
- Selectable slots with visual feedback
- Alerts for selected item

## Usage:
1. Open `index.html` in Replit.
2. Click 'Add Random Item' to populate the inventory.
3. Click any item slot to select and view it.

This can be expanded with:
- Item images and drag/drop
- Equip/Use logic
- Persistent save with Firebase
