
// Initialize Firebase (Replace with your Firebase config)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  databaseURL: "https://your-project.firebaseio.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

function saveGame() {
  const user = document.getElementById("username").value;
  const state = document.getElementById("gamestate").value;
  if (user && state) {
    db.ref("saves/" + user).set({ state: state });
    document.getElementById("output").innerText = "Game saved!";
  }
}

function loadGame() {
  const user = document.getElementById("username").value;
  db.ref("saves/" + user).get().then(snapshot => {
    if (snapshot.exists()) {
      document.getElementById("output").innerText = "Loaded: " + snapshot.val().state;
    } else {
      document.getElementById("output").innerText = "No data found.";
    }
  });
}
