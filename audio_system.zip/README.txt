
# Section 16: Sound Effects and Background Music System

This demo shows how to use HTML5 Audio for sound effects and music.

## Features:
- Plays sound effects on button press
- Toggle background music on/off
- Supports MP3 (other formats like OGG can be added)

## Usage:
1. Add your audio files named `background.mp3` and `click.mp3`.
2. Open `index.html` in Replit or browser.
3. Click buttons to test the sound system.

### Tips:
- Preload and optimize audio for web.
- Use audio sprites for performance.
- Store volume/mute state in Firebase if desired.
