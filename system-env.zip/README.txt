
# Section 1: System & Environment

This sets up the basic 3D environment using Three.js. It includes:
- Scene initialization
- Camera setup
- Directional and ambient lighting
- A ground plane to walk on

## To Run:
1. Open `index.html` in Replit or a local server.
2. The 3D environment should load with basic lighting and terrain.

You can expand this with player controls, more assets, and dynamic environments.
