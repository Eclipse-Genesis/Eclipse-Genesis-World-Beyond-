
# Section 8: Saving & Loading Game State with Firebase

This section provides a basic setup for saving and loading player data (e.g., XP) using Firebase Firestore.

## Setup Instructions:
1. Go to [Firebase Console](https://console.firebase.google.com/) and create a new project.
2. Enable Firestore Database in your project.
3. Replace the `firebaseConfig` values in `firebase_save.js` with your Firebase project's config.
4. Upload this project to Replit and test by entering a username and XP, then clicking Save and Load.

## Features:
- Save and load user XP by username
- Real-time Firestore integration
- Modular Firebase setup using ESM imports
