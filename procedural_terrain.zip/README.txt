
# Section 20: Procedural Terrain Generation

This example uses Three.js to create a dynamic procedural terrain.

## Features:
- Procedurally generated height map using sine/cosine waves and noise
- OrbitControls for full camera movement
- Lighting and shading for realistic terrain

## Setup:
1. Run `index.html` in Replit or locally.
2. Explore the 3D terrain with your mouse.
3. Adjust `generateTerrain()` for new patterns (Perlin noise, fault lines, etc.)

## Next Steps:
- Add textures or a height map image
- Place objects on terrain (trees, rocks)
- Generate infinite terrain with tiling chunks
