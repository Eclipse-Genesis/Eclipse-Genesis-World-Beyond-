
let scene, camera, renderer, controls;

init();
generateTerrain();

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x99ccff);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.set(0, 30, 50);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(10, 50, 10);
  scene.add(light);
}

function generateTerrain() {
  const width = 100;
  const height = 100;
  const segments = 64;
  const geometry = new THREE.PlaneGeometry(width, height, segments, segments);
  const material = new THREE.MeshStandardMaterial({ color: 0x556b2f, wireframe: false, side: THREE.DoubleSide });

  geometry.rotateX(-Math.PI / 2);

  for (let i = 0; i < geometry.attributes.position.count; i++) {
    const x = geometry.attributes.position.getX(i);
    const y = geometry.attributes.position.getY(i);
    const z = Math.sin(x * 0.1) * Math.cos(y * 0.1) * 5 + Math.random() * 0.5;
    geometry.attributes.position.setZ(i, z);
  }

  geometry.computeVertexNormals();
  const terrain = new THREE.Mesh(geometry, material);
  scene.add(terrain);

  animate();
}

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
