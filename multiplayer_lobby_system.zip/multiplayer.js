
const lobbies = ["Lobby1", "Lobby2", "Lobby3"];
function joinLobby() {
  const lobby = lobbies[Math.floor(Math.random() * lobbies.length)];
  document.getElementById("lobbyList").textContent = "Joined " + lobby;
}
