
# Multiplayer Lobby System
Joins players into a random lobby. Expand with Firebase real-time database for matchmaking.
