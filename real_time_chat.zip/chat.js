
const messages = [];

function sendMessage() {
  const username = document.getElementById("username").value.trim();
  const message = document.getElementById("message").value.trim();

  if (!username || !message) return;

  messages.push({ username, message });
  updateMessages();
  document.getElementById("message").value = "";
}

function updateMessages() {
  const container = document.getElementById("messages");
  container.innerHTML = "";
  messages.forEach(msg => {
    const div = document.createElement("div");
    div.textContent = msg.username + ": " + msg.message;
    container.appendChild(div);
  });
  container.scrollTop = container.scrollHeight;
}
