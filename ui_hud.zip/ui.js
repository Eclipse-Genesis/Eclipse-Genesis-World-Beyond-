
let health = 100;
let stamina = 100;
let xp = 0;

const healthBar = document.getElementById("healthBar");
const staminaBar = document.getElementById("staminaBar");
const xpDisplay = document.getElementById("xpDisplay");

function updateHUD() {
  healthBar.style.width = health + "%";
  staminaBar.style.width = stamina + "%";
  xpDisplay.textContent = xp;
}

function simulateGame() {
  setInterval(() => {
    health = Math.max(0, health - Math.random() * 2);
    stamina = Math.max(0, stamina - Math.random() * 1.5);
    xp += Math.floor(Math.random() * 3);
    updateHUD();
  }, 1000);
}

updateHUD();
simulateGame();
