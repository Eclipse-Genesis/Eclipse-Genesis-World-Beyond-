
// Firebase config (replace with your actual config)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  databaseURL: "https://your-project.firebaseio.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const userId = "player1"; // replace with current player ID
const craftingArea = document.getElementById("craftingArea");

const recipes = [
  {
    name: "Iron Sword",
    required: { wood: 1, iron: 2 },
    result: { name: "Iron Sword" }
  },
  {
    name: "Health Potion",
    required: { herb: 2, water: 1 },
    result: { name: "Health Potion" }
  }
];

function renderCraftingUI(inventory) {
  craftingArea.innerHTML = '';
  recipes.forEach(recipe => {
    const recipeDiv = document.createElement("div");
    recipeDiv.className = "recipe";
    recipeDiv.innerHTML = `<h3>${recipe.name}</h3><p>Needs: ${Object.entries(recipe.required).map(([k,v]) => \`\${v} \${k}\`).join(", ")}</p>`;
    const button = document.createElement("button");
    button.textContent = "Craft";
    button.onclick = () => attemptCraft(recipe, inventory);
    recipeDiv.appendChild(button);
    craftingArea.appendChild(recipeDiv);
  });
}

function attemptCraft(recipe, inventory) {
  const invCopy = { ...inventory };
  for (const [item, qty] of Object.entries(recipe.required)) {
    if (!invCopy[item] || invCopy[item] < qty) {
      alert("Not enough " + item);
      return;
    }
  }
  // Deduct materials
  for (const [item, qty] of Object.entries(recipe.required)) {
    invCopy[item] -= qty;
  }
  // Add crafted item
  invCopy[recipe.result.name] = (invCopy[recipe.result.name] || 0) + 1;
  saveInventory(invCopy);
  alert(recipe.result.name + " crafted!");
}

function loadInventory() {
  db.ref("inventory/" + userId).get().then(snapshot => {
    const inventory = snapshot.exists() ? snapshot.val().items || {} : {};
    renderCraftingUI(inventory);
  });
}

function saveInventory(updated) {
  db.ref("inventory/" + userId + "/items").set(updated);
}

loadInventory(); // Load on page load
