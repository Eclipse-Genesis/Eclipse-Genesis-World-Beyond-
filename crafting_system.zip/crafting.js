
const recipes = {
  "Iron Sword": ["Iron", "Wood"],
  "Health Potion": ["Herb", "Water"]
};
const craftingDiv = document.getElementById("crafting");
function displayRecipes() {
  craftingDiv.innerHTML = Object.entries(recipes).map(([item, ingredients]) =>
    `<div>${item}: ${ingredients.join(", ")}</div>`).join('');
}
displayRecipes();
