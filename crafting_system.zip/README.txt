
# Crafting System
Displays available crafting recipes. Future expansions include item creation and Firebase inventory sync.
