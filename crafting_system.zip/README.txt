
# Section 33: Crafting System and Item Recipes

## Description
This module provides a simple crafting system where players can combine ingredients to create items based on predefined recipes. All inventory changes are synced with Firebase Realtime Database.

## Features:
- Display of multiple craftable recipes
- Material checks before crafting
- Deduction and addition of items from/to player inventory
- Firebase Realtime Database syncing

## Setup:
1. Replace Firebase config in `crafting.js` with your actual config values.
2. Make sure the `inventory` node in Firebase has the required materials for testing.
3. Open `index.html` to view and use the crafting interface.

## Future Enhancements:
- Add crafting animations
- Unlock recipes based on progression
- Drag/drop ingredients or modular recipe builder UI
