
# Section 4: Inventory & Items System

This section introduces a basic inventory system that auto-fills with "Potion" items and allows item use.

## Features:
- 10-slot inventory displayed at the bottom-left
- Items auto-add every few seconds
- Clicking an item "uses" it and removes it from inventory

## How to Use:
1. Open `index.html` in Replit.
2. Watch the inventory fill up with potions.
3. Click on a potion to use and remove it.

This is a great foundation for building an RPG or survival-style game.
