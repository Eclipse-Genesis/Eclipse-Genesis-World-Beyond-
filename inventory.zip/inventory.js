
import * as THREE from 'three';

let scene, camera, renderer;
let inventory = new Array(10).fill(null);

init();
animate();
renderInventory();

function init() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.z = 5;

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshBasicMaterial({ color: 0x0077ff });
  const cube = new THREE.Mesh(geometry, material);
  scene.add(cube);

  // Simulate adding items
  setInterval(() => {
    addItem({ name: "Potion", id: "potion" + Math.floor(Math.random() * 100) });
  }, 3000);
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

function addItem(item) {
  const index = inventory.findIndex(i => i === null);
  if (index !== -1) {
    inventory[index] = item;
    renderInventory();
  } else {
    alert("Inventory Full!");
  }
}

function renderInventory() {
  const invContainer = document.getElementById("inventory");
  invContainer.innerHTML = "";
  inventory.forEach((item, i) => {
    const slot = document.createElement("div");
    slot.className = "slot";
    slot.textContent = item ? item.name : "";
    slot.onclick = () => {
      if (item) {
        alert("Used " + item.name);
        inventory[i] = null;
        renderInventory();
      }
    };
    invContainer.appendChild(slot);
  });
}
