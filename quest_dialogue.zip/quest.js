
const dialogues = {
  start: {
    text: "Greetings, traveler. What brings you to these shores?",
    choices: [
      { text: "I'm searching for the Eon Core.", next: "eonCore" },
      { text: "Just exploring.", next: "exploring" }
    ]
  },
  eonCore: {
    text: "The Eon Core is a myth. But some say it's buried beneath the ancient ruins.",
    choices: [
      { text: "Where are these ruins?", next: "ruins" },
      { text: "I don't believe in myths.", next: "myth" }
    ]
  },
  exploring: {
    text: "Then take care — this land holds wonders and horrors alike.",
    choices: []
  },
  ruins: {
    text: "Beyond the forest, past the mountains. You'll need a key.",
    choices: [
      { text: "Where can I find the key?", next: "key" }
    ]
  },
  myth: {
    text: "Suit yourself. Many who scoffed are now lost beneath the waves.",
    choices: []
  },
  key: {
    text: "Seek the hermit in the crystal cave. He guards the past.",
    choices: []
  }
};

function showDialogue(key) {
  const dialogue = dialogues[key];
  document.getElementById("dialogueText").textContent = dialogue.text;
  const choicesDiv = document.getElementById("choices");
  choicesDiv.innerHTML = "";
  dialogue.choices.forEach(choice => {
    const btn = document.createElement("button");
    btn.textContent = choice.text;
    btn.onclick = () => showDialogue(choice.next);
    choicesDiv.appendChild(btn);
  });
}

showDialogue("start");
