
# Section 23: Quest and Dialogue System

This is a simple branching dialogue and quest system implemented in HTML and JavaScript.

## Features:
- Branching dialogue trees
- Dynamic rendering of player choices
- Progression based on player decisions

## Setup:
1. Open `index.html` in Replit or your browser.
2. Click through the dialogue and make choices to explore quest paths.

## Expansion Ideas:
- Store player choices in Firebase to track quest progress.
- Add NPC names, voiceovers, and animations.
- Tie dialogue outcomes to rewards, inventory items, and events.
